// LilyGo T-Beam-1W variant.h
// Configuration based on Meshtastic PR #8967 and LilyGO documentation

#pragma once

// I2C for OLED display (SH1106 at 0x3C)
#define I2C_SDA 8
#define I2C_SCL 9

// GPS - Quectel L76K
// GNSS_TXD (IO5) = GPS transmits → MCU RX (setPins rxPin)
// GNSS_RXD (IO6) = GPS receives → MCU TX (setPins txPin)
#define PIN_GPS_TX 5       // MCU receives from GPS TX
#define PIN_GPS_RX 6       // MCU transmits to GPS RX
#define PIN_GPS_PPS 7      // GPS PPS output
#define PIN_GPS_EN 16      // GPS wake-up/enable (GPS_EN_PIN in LilyGO code)
#define HAS_GPS 1
#define GPS_BAUDRATE 9600

// Buttons
#define BUTTON_PIN 0         // BUTTON 1 (boot)
#define BUTTON_PIN_ALT 17    // BUTTON 2

// SPI (shared by LoRa and SD)
#define SPI_MOSI 11
#define SPI_SCK 13
#define SPI_MISO 12
#define SPI_CS 10

// SD Card
#define HAS_SDCARD
#define SDCARD_USE_SPI1
#define SDCARD_CS SPI_CS

// LoRa Radio - SX1262 with 1W PA
#define USE_SX1262

#define LORA_SCK SPI_SCK
#define LORA_MISO SPI_MISO
#define LORA_MOSI SPI_MOSI
#define LORA_CS 15
#define LORA_RESET 3
#define LORA_DIO1 1
#define LORA_BUSY 38

// CRITICAL: Radio power enable - MUST be HIGH before lora.begin()!
// GPIO 40 powers the SX1262 + PA module via LDO
#define SX126X_POWER_EN 40

#ifdef USE_SX1262
#define SX126X_CS LORA_CS
#define SX126X_DIO1 LORA_DIO1
#define SX126X_BUSY LORA_BUSY
#define SX126X_RESET LORA_RESET

// RF switching configuration for 1W PA module
// DIO2 controls PA (via SX126X_DIO2_AS_RF_SWITCH)
// CTRL PIN (GPIO 21) controls LNA - must be HIGH during RX
// Truth table: DIO2=1,CTRL=0 -> TX (PA on, LNA off)
//              DIO2=0,CTRL=1 -> RX (PA off, LNA on)
#define SX126X_DIO2_AS_RF_SWITCH
#define SX126X_RXEN 21  // LNA enable - HIGH during RX

// TCXO voltage - required for radio init
#define SX126X_DIO3_TCXO_VOLTAGE 3.0

#define SX126X_MAX_POWER 22
#endif

// LED
#define LED_PIN 18
#define LED_STATE_ON 1  // HIGH = ON

// Battery ADC
#define BATTERY_PIN 4
#define ADC_CHANNEL ADC1_GPIO4_CHANNEL
#define BATTERY_SENSE_SAMPLES 30
#define ADC_MULTIPLIER 3.0

// NTC thermistor (Murata NCP18XH103F03RB, 10k, B25/50=3380K)
// Divider: 3.3V -> NTC -> GPIO14 -> 10k pull-down -> GND (Vadc rises with temp)
#define NTC_PIN 14
#define NTC_B 3380.0f
#define NTC_R25 10000.0f
#define NTC_R_FIXED 10000.0f
#define NTC_VCC_MV 3300.0f

// Fan control (GPIO41). NTC is PA-adjacent PCB temp, not die temp, so trip
// well below the SX1262/ESP32 85C operating limit. Hardware testing confirmed
// that this fan/MOSFET path is on/off; PWM below 100% does not spin the fan.
#define FAN_CTRL_PIN 41
#define FAN_TX_COOLDOWN_MS 15000
#define FAN_DEFAULT_LO_C 30   // off below typical indoor idle (~86F)
#define FAN_DEFAULT_HI_C 36   // on at ~97F PCB; still far below 85C chip ratings

// PA Ramp Time - T-Beam 1W requires >800us stabilization (default is 200us)
// Value 0x05 = RADIOLIB_SX126X_PA_RAMP_800U
#define SX126X_PA_RAMP_US 0x05

// Display - SH1106 OLED (128x64)
#define USE_SH1106
#define OLED_WIDTH 128
#define OLED_HEIGHT 64

// 32768 Hz crystal present
#define HAS_32768HZ 1
